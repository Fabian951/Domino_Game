package com.example.domino_game.view.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino_game.model.Cell
import com.example.domino_game.model.Move
import com.example.domino_game.model.Player

@Composable
fun GridBoardView(
    boardCells: List<Cell>,
    players: List<Player>,
    validMoves: List<Move>,
    previewMove: Move?,
    onCellClick: (row: Int, col: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val playerColors = listOf(
        Color(0xFF1E88E5), // Jugador 1 (Azul)
        Color(0xFF8E24AA), // Jugador 2 (Púrpura)
        Color(0xFF43A047), // Jugador 3 (Verde)
        Color(0xFFFB8C00)  // Jugador 4 (Naranja)
    )

    val validAnchorPositions = validMoves.map { Pair(it.row, it.col) }.toSet()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        val boardSize = if (maxWidth < maxHeight) maxWidth else maxHeight

        Column(
            modifier = Modifier
                .size(boardSize)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF144518)) // Verde fieltro premium
                .border(3.dp, Color(0xFF0A300D), RoundedCornerShape(16.dp))
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            for (r in 0 until 10) {
                Row(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    for (c in 0 until 10) {
                        val cell = boardCells.firstOrNull { it.row == r && it.col == c }
                            ?: Cell(id = "${r}_${c}", row = r, col = c)

                        val ownerIndex = players.indexOfFirst { it.uid == cell.ownerId }
                        val ownerColor = if (ownerIndex != -1) playerColors[ownerIndex % playerColors.size] else Color.Transparent

                        val isPreview1 = previewMove != null && previewMove.row == r && previewMove.col == c
                        val isPreview2 = previewMove != null && previewMove.row2 == r && previewMove.col2 == c
                        val previewValue = if (isPreview1) previewMove?.val1 else if (isPreview2) previewMove?.val2 else null

                        TerritoryCellView(
                            cell = cell,
                            ownerColor = ownerColor,
                            isValidAnchor = validAnchorPositions.contains(Pair(r, c)),
                            previewValue = previewValue,
                            onClick = { onCellClick(r, c) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TerritoryCellView(
    cell: Cell,
    ownerColor: Color,
    isValidAnchor: Boolean,
    previewValue: Int?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDashedFortress = cell.type.uppercase() == "FORTRESS" && cell.conquestCount == 1

    val borderColor = when {
        isValidAnchor -> MaterialTheme.colorScheme.primary
        ownerColor != Color.Transparent -> ownerColor
        isDashedFortress -> Color(0xFF78909C)
        else -> Color(0xFF2E7D32)
    }

    val borderWidth = when {
        isValidAnchor -> 3.dp
        ownerColor != Color.Transparent -> 2.5.dp
        else -> 1.dp
    }

    val backgroundColor = when {
        previewValue != null -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
        isValidAnchor -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        ownerColor != Color.Transparent -> ownerColor.copy(alpha = 0.28f)
        else -> when (cell.type.uppercase()) {
            "BONUS" -> Color(0xFF332B10)
            "TREASURE" -> Color(0xFF102E33)
            "TRAP" -> Color(0xFF331515)
            "FORTRESS" -> Color(0xFF263238)
            "PORTAL" -> Color(0xFF2E1A47)
            else -> Color(0xFF1E6322)
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(backgroundColor)
            .border(borderWidth, borderColor, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(1.dp),
        contentAlignment = Alignment.Center
    ) {
        val displayVal = previewValue ?: cell.value

        if (displayVal != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(1.dp)
                    .background(Color(0xFF0F2B12).copy(alpha = 0.6f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = displayVal.toString(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }

            if (isDashedFortress) {
                Text(
                    text = "1/2",
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD54F),
                    modifier = Modifier.align(Alignment.TopEnd).padding(1.dp)
                )
            }
        } else {
            val specialTag = when (cell.type.uppercase()) {
                "BONUS" -> "⭐"
                "TREASURE" -> "💎"
                "TRAP" -> "⚠️"
                "FORTRESS" -> if (cell.conquestCount == 1) "1/2" else "🏰"
                "PORTAL" -> "🌀"
                else -> ""
            }

            if (specialTag.isNotEmpty()) {
                Text(
                    text = specialTag,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
